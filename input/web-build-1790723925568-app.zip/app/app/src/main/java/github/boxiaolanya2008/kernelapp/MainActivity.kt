package github.boxiaolanya2008.kernelapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import github.boxiaolanya2008.kernelapp.ui.theme.KernelappTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KernelappTheme {
                KernelAppRoot()
            }
        }
    }
}

@Composable
fun KernelAppRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var connected by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("(未连接)") }
    var tasks by remember { mutableStateOf<List<KernelBridge.TaskItem>>(emptyList()) }
    var rootEnabled by remember { mutableStateOf(false) }
    var grantMode by remember { mutableStateOf(0) }

    fun refreshStatus() {
        scope.launch(Dispatchers.IO) {
            val ok = KernelBridge.ping()
            val st = KernelBridge.status()
            withContext(Dispatchers.Main) {
                connected = ok
                status = if (ok) (st ?: "connected") else "(daemon 不可达)"
            }
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            refreshStatus()
            delay(2000)
        }
    }

    fun refreshTasks() {
        if (!connected) return
        scope.launch(Dispatchers.IO) {
            val list = KernelBridge.taskList()
            withContext(Dispatchers.Main) { tasks = list }
        }
    }

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        Column(Modifier.padding(innerPadding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 },
                    text = { Text("主页") })
                Tab(selected = tab == 1, onClick = { tab = 1 },
                    text = { Text("进程列表") })
                Tab(selected = tab == 2, onClick = { tab = 2 },
                    text = { Text("进程内存") })
            }

            when (tab) {
                0 -> HomeTab(
                    connected = connected,
                    status = status,
                    onRefresh = { refreshStatus() },
                    rootEnabled = rootEnabled,
                    onRootToggle = { rootEnabled = it },
                    grantMode = grantMode,
                    onModeChange = { grantMode = it },
                )
                1 -> ProcessTab(
                    tasks = tasks,
                    connected = connected,
                    rootEnabled = rootEnabled,
                    grantMode = grantMode,
                    onRefresh = { refreshTasks() },
                    onGrant = { item ->
                        scope.launch(Dispatchers.IO) {
                            val ok = KernelBridge.grantRoot(item.task)
                            withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    context,
                                    if (ok) "已提权 ${item.comm} (pid=${item.pid})"
                                    else "提权失败 ${item.comm}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    },
                    onGrantAll = {
                        scope.launch(Dispatchers.IO) {
                            val res = KernelBridge.grantAll()
                            withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    context,
                                    if (res == null) "全局提权失败 (daemon 不可达?)"
                                    else "全局提权完成: 成功 ${res.granted}, 跳过内核线程 ${res.skipped}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    },
                )
                2 -> MemoryTab(
                    connected = connected,
                    tasks = tasks,
                    onRefreshTasks = { refreshTasks() },
                )
            }
        }
    }
}

@Composable
fun HomeTab(
    connected: Boolean,
    status: String,
    onRefresh: () -> Unit,
    rootEnabled: Boolean,
    onRootToggle: (Boolean) -> Unit,
    grantMode: Int,
    onModeChange: (Int) -> Unit,
) {
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("KernelApp", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("daemon 状态: ${if (connected) "已连接" else "未连接"}")
                Text(status, style = MaterialTheme.typography.bodySmall)
                Button(onClick = onRefresh, modifier = Modifier.padding(top = 8.dp)) {
                    Text("刷新状态")
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("使用说明", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(4.dp))
                Text(
                    "1. 推送 preload.so 并在 adb shell 中执行：\n" +
                        "   LD_PRELOAD=/data/local/tmp/preload.so /system/bin/true\n" +
                        "2. 漏洞跑完后会自动启动 io daemon\n" +
                        "3. 回到本 app 点「刷新状态」，连接成功后可操作\n\n" +
                        "此 app 不内置提权，只作为 daemon 的客户端。",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Switch(checked = rootEnabled, onCheckedChange = onRootToggle)
                    Column {
                        Text("启用提权功能", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "开启后可在进程列表中对目标进程授予 root",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("提权模式", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = grantMode == 0,
                        onClick = { onModeChange(0) },
                        label = { Text("单进程") }
                    )
                    FilterChip(
                        selected = grantMode == 1,
                        onClick = { onModeChange(1) },
                        label = { Text("全局") }
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    if (grantMode == 0)
                        "单进程：在进程列表里逐个选择目标提权"
                    else
                        "全局：遍历所有用户进程提权（自动跳过内核线程）",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun ProcessTab(
    tasks: List<KernelBridge.TaskItem>,
    connected: Boolean,
    rootEnabled: Boolean,
    grantMode: Int,
    onRefresh: () -> Unit,
    onGrant: (KernelBridge.TaskItem) -> Unit,
    onGrantAll: () -> Unit,
) {
    var query by remember { mutableStateOf("") }

    val filtered = remember(tasks, query) {
        if (query.isBlank()) {
            tasks
        } else {
            val q = query.trim().lowercase()
            tasks.filter {
                it.comm.lowercase().contains(q) ||
                    it.pid.toString() == q ||
                    it.tgid.toString() == q ||
                    it.task.toString(16).contains(q.removePrefix("0x"))
            }
        }
    }

    Column(Modifier.padding(16.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(onClick = onRefresh, enabled = connected) {
                Text("刷新")
            }
            if (grantMode == 1) {
                Button(
                    onClick = onGrantAll,
                    enabled = connected && rootEnabled,
                    modifier = Modifier.width(120.dp)
                ) {
                    Text("全局提权")
                }
            }
            Text(
                if (connected) "共 ${tasks.size} 个进程，匹配 ${filtered.size}" else "daemon 未连接",
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("搜索进程名 / pid / task 地址") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (!rootEnabled) {
            Spacer(Modifier.height(8.dp))
            Text(
                "提权功能未开启，回主页打开开关",
                color = Color(0xFFB71C1C),
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(8.dp))

        if (tasks.isEmpty()) {
            Text("列表为空，点刷新。", style = MaterialTheme.typography.bodySmall)
        } else if (filtered.isEmpty()) {
            Text("没有匹配「${query.trim()}」的进程。", style = MaterialTheme.typography.bodySmall)
        } else {
            LazyColumn {
                items(filtered, key = { it.task }) { item ->
                    TaskRow(
                        item = item,
                        rootEnabled = rootEnabled && grantMode == 0,
                        onGrant = onGrant
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
fun TaskRow(
    item: KernelBridge.TaskItem,
    rootEnabled: Boolean,
    onGrant: (KernelBridge.TaskItem) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(item.comm, style = MaterialTheme.typography.titleSmall,
                 maxLines = 1)
            Text(
                "pid=%d tgid=%d\n task=%016x\ncred=%016x".format(
                    item.pid, item.tgid, item.task, item.cred
                ),
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                maxLines = 3
            )
        }
        FilledTonalButton(
            onClick = { onGrant(item) },
            enabled = rootEnabled,
            modifier = Modifier
                .width(88.dp)
                .height(40.dp),
            shape = MaterialTheme.shapes.medium
        ) {
            Text("提权", style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun MemoryTab(
    connected: Boolean,
    tasks: List<KernelBridge.TaskItem>,
    onRefreshTasks: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<KernelBridge.TaskItem?>(null) }
    var cred by remember { mutableStateOf<KernelBridge.CredInfo?>(null) }
    var credError by remember { mutableStateOf("") }
    var uidText by remember { mutableStateOf("0") }
    var capsText by remember { mutableStateOf("") }
    var sidText by remember { mutableStateOf("1") }
    var fieldResult by remember { mutableStateOf("") }
    var showAdvanced by remember { mutableStateOf(false) }

    // Advanced raw read/write state.
    var addrText by remember { mutableStateOf("0xffffffc080000000") }
    var valueText by remember { mutableStateOf("0") }
    var readResult by remember { mutableStateOf("") }
    var writeResult by remember { mutableStateOf("") }
    var logText by remember { mutableStateOf("") }

    fun parseAddr(s: String): Long? = s.trim().toLongOrNull(16)

    fun loadCred(item: KernelBridge.TaskItem) {
        selected = item
        scope.launch(Dispatchers.IO) {
            val info = KernelBridge.credInfo(item.task)
            withContext(Dispatchers.Main) {
                if (info == null) {
                    cred = null
                    credError = "读取 cred 失败 (task=%016x)".format(item.task)
                } else {
                    cred = info
                    credError = ""
                    uidText = info.uid.toString()
                    capsText = info.caps.joinToString(" ") { "0x%016x".format(it) }
                    sidText = info.sid.toString()
                    fieldResult = ""
                }
            }
        }
    }

    Column(
        Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            "daemon: ${if (connected) "已连接" else "未连接"}",
            color = if (connected) Color(0xFF1B5E20) else Color(0xFFB71C1C)
        )

        Text("选择应用", style = MaterialTheme.typography.titleSmall)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = onRefreshTasks, enabled = connected) {
                Text("刷新列表")
            }
            Text("共 ${tasks.size} 个进程", style = MaterialTheme.typography.bodySmall)
        }

        if (tasks.isNotEmpty()) {
            LazyColumn(Modifier.height(220.dp)) {
                items(tasks, key = { it.task }) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { loadCred(item) }
                            .padding(vertical = 4.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            item.comm,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            "pid=%d".format(item.pid),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }

        selected?.let { sel ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        "已选: ${sel.comm} (pid=${sel.pid})",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        "task=%016x\ncred=%016x".format(sel.task, sel.cred),
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(Modifier.height(4.dp))

                    val c = cred
                    if (c != null) {
                        Text(
                            "uid=%d gid=%d euid=%d egid=%d\n" +
                                "fsuid=%d fsgid=%d suid=%d sgid=%d\n" +
                                "securebits=%d caps=%s\n" +
                                "sid=%d".format(
                                    c.uid, c.gid, c.euid, c.egid,
                                    c.fsuid, c.fsgid, c.suid, c.sgid,
                                    c.securebits,
                                    c.caps.joinToString(",") { "0x%x".format(it) },
                                    c.sid
                                ),
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace
                        )
                    } else if (credError.isNotEmpty()) {
                        Text(credError, color = Color(0xFFB71C1C),
                             style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("修改字段", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "uid/gid/euid/egid/fsuid/fsgid 统一改为:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = uidText,
                        onValueChange = { uidText = it },
                        label = { Text("新 uid (一般填 0)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            val v = uidText.trim().toLongOrNull() ?: return@Button
                            scope.launch(Dispatchers.IO) {
                                val ok = KernelBridge.modifyCredField(sel.task, 0, v)
                                withContext(Dispatchers.Main) {
                                    fieldResult = if (ok) "uid 已改为 $v"
                                    else "uid 修改失败"
                                    loadCred(sel)
                                }
                            }
                        },
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text("修改 uid")
                    }

                    Text("caps (5 个 64 位值, 空格分隔):",
                         style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = capsText,
                        onValueChange = { capsText = it },
                        label = { Text("caps") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            val parts = capsText.trim().split(Regex("\\s+"))
                            if (parts.size != 5) {
                                fieldResult = "需要 5 个值"
                                return@Button
                            }
                            var ok = false
                            for (p in parts) {
                                val v = p.removePrefix("0x").toLongOrNull(16) ?: 0L
                                ok = KernelBridge.modifyCredField(sel.task, 2, v)
                            }
                            fieldResult = if (ok) "caps 已写入"
                            else "caps 写入失败"
                            loadCred(sel)
                        },
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text("写入 caps")
                    }

                    Text("SELinux sid (1=kernel, 建议 1):",
                         style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = sidText,
                        onValueChange = { sidText = it },
                        label = { Text("sid") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            val v = sidText.trim().toLongOrNull() ?: return@Button
                            scope.launch(Dispatchers.IO) {
                                val ok = KernelBridge.modifyCredField(sel.task, 3, v)
                                withContext(Dispatchers.Main) {
                                    fieldResult = if (ok) "sid 已改为 $v"
                                    else "sid 修改失败"
                                    loadCred(sel)
                                }
                            }
                        },
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text("修改 sid")
                    }

                    if (fieldResult.isNotEmpty()) {
                        Text(fieldResult, color = Color(0xFF1B5E20),
                             style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { showAdvanced = !showAdvanced },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (showAdvanced) "收起高级读写" else "展开高级读写 (裸地址)")
        }

        if (showAdvanced) {
            OutlinedTextField(
                value = addrText,
                onValueChange = { addrText = it },
                label = { Text("目标地址 (hex)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(onClick = {
                    val a = parseAddr(addrText)
                    if (a == null) { readResult = "地址无效"; return@Button }
                    scope.launch(Dispatchers.IO) {
                        val v = KernelBridge.kernelRead64(a)
                        withContext(Dispatchers.Main) {
                            readResult = "读取 %016x = %016x".format(a, v)
                        }
                    }
                }) {
                    Text("读取64位")
                }
                Text(readResult, style = MaterialTheme.typography.bodySmall)
            }

            OutlinedTextField(
                value = valueText,
                onValueChange = { valueText = it },
                label = { Text("写入值 (hex)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(onClick = {
                    val a = parseAddr(addrText) ?: return@Button
                    val v = valueText.trim().toLongOrNull(16) ?: return@Button
                    scope.launch(Dispatchers.IO) {
                        val ok = KernelBridge.kernelWrite64(a, v)
                        withContext(Dispatchers.Main) {
                            writeResult = if (ok) "写入 %016x <- %016x 成功".format(a, v)
                            else "写入失败"
                        }
                    }
                }) {
                    Text("写入64位")
                }
                Text(writeResult, style = MaterialTheme.typography.bodySmall)
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp).height(160.dp)) {
                    Text("日志", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        logText.ifEmpty { "(空)" },
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    )
                }
            }

            Text(
                "高危：写内核 text 段、未映射地址或错误指针位置会 page fault，直接 panic 重启。",
                color = Color(0xFFB71C1C),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
